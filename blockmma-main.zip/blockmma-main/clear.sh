cd ./kernel_module && make clean
cd ../library && make clean
cd ../benchmark && make clean

cd ..